﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Proximity_Search;
using System;
using System.Linq;

namespace ProximitySearchTests
{
    [TestClass]
    public class FileReaderTests
    {
        [TestMethod]
        public void TestReadFile()
        {
            var fileName = "input2.txt";
            var words = FileReader.ReadFile(fileName).ToList();

            Assert.AreEqual(7, words.Count);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void InvalidFileThrowException()
        {
            var fileName = "input2345.txt";
            FileReader.ReadFile(fileName).ToList();
        }
    }
}

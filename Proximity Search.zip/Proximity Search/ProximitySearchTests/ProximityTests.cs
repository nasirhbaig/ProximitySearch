﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Proximity_Search;

namespace ProximitySearchTests
{
    [TestClass]
    public class ProximityTests
    {
        [TestMethod]
        public void TestProximitySearch()
        {
            var fileName = "input1.txt";
            var keyword1 = "the";
            var keyword2 = "canal";
            var words = new List<string>() { "the", "canal" };

            Assert.AreEqual(11, Proximity.ProximitySearch(keyword1, keyword2, 6, fileName));
            Assert.AreEqual(11, Proximity.ProximitySearch(words, 6, fileName));

            fileName = "input2.txt";
            Assert.AreEqual(3, Proximity.ProximitySearch(keyword1, keyword2, 6, fileName));
            Assert.AreEqual(1, Proximity.ProximitySearch(keyword1, keyword2, 3, fileName));

            Assert.AreEqual(3, Proximity.ProximitySearch(words, 6, fileName));
            Assert.AreEqual(1, Proximity.ProximitySearch(words, 3, fileName));

            fileName = "input3.txt";
            Assert.AreEqual(16, Proximity.ProximitySearch(keyword1, keyword2, 8, fileName));
            Assert.AreEqual(16, Proximity.ProximitySearch(words, 8, fileName));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void InvalidKeywordShouldThrowException()
        {
            Proximity.ProximitySearch("", "", 6, "input1.txt");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void InvalidRangeShouldThrowException()
        {
            Proximity.ProximitySearch("the", "canal", 0, "input1.txt");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void InvalidFileThrowException()
        {
            Proximity.ProximitySearch("the", "canal", 5, "input123.txt");
        }

        [TestMethod]
        public void TestProximitySearch2()
        {
            var fileName = "input1.txt";
            var keyword1 = "the";
            var keyword2 = "canal";

            Assert.AreEqual(11, Proximity.ProximitySearch2(keyword1, keyword2, 6, fileName));

            fileName = "input2.txt";
            Assert.AreEqual(3, Proximity.ProximitySearch2(keyword1, keyword2, 6, fileName));
            Assert.AreEqual(1, Proximity.ProximitySearch2(keyword1, keyword2, 3, fileName));

            fileName = "input3.txt";
            Assert.AreEqual(16, Proximity.ProximitySearch2(keyword1, keyword2, 8, fileName));
        }
    }
}

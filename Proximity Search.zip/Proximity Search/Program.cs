﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Proximity_Search
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length < 4)
            {
                Console.WriteLine("Please enter valid arguments.");
                Console.WriteLine("Usage: Proximity Search <keyword1> <keyword2> <range> <input_filename>");
                return;
            }

            var keyword1 = args[0];
            var keyword2 = args[1];

            if(string.IsNullOrEmpty(keyword1) || string.IsNullOrEmpty(keyword2))
            {
                Console.WriteLine("Please enter a valid value for keyword.");
                Console.WriteLine("Usage: Proximity Search <keyword1> <keyword2> <range> <input_filename>");
                return;
            }

            int range;
            var isRangeValid = int.TryParse(args[2], out range);
            if (!isRangeValid || range <= 0)
            {
                Console.WriteLine($"Invalud input [{range}] for range. Please enter a positive value for range.");
                Console.WriteLine("Usage: Proximity Search <keyword1> <keyword2> <range> <input_filename>");
                return;
            }

            var fileName = args[3];
            if(!File.Exists(fileName))
            {
                Console.WriteLine($"File [{fileName}] couldn't be found. Please enter file name with correct path.");
                Console.WriteLine("Usage: Proximity Search <keyword1> <keyword2> <range> <input_filename>");
                return;
            }

            var proximityCount = Proximity.ProximitySearch(keyword1, keyword2, range, fileName);

            List<string> words = new List<string>() { "the", "canal" };

            var proximityCount2 = Proximity.ProximitySearch(words, range, fileName);

            Console.WriteLine($"Proximity Count for words [{keyword1}] and [{keyword2}] in the range [{range}] is [{proximityCount}].");

            Console.WriteLine("\nEnter any key to exit");
            Console.ReadKey();
        }
    }
}

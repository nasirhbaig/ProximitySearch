﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Proximity_Search
{
    public static class Proximity
    {
        // Time: O(n), Space: O(range)
        public static int ProximitySearch(string keyword1, string keyword2, int range, string fileName)
        {
            var keyword1Count = 0;
            var keyword2Count = 0;
            var proximityCount = 0;

            ValidateArguments(keyword1, keyword2, range, fileName);

            var index = 0;
            var wordsInRange = new Queue<string>();

            foreach (var word in FileReader.ReadFile(fileName))
            {
                //int window = index - range;

                //if (window >= 0)
                if(wordsInRange.Count >= range)
                {
                    var first = wordsInRange.Peek();

                    if (first == keyword1)
                    {
                        keyword1Count--;
                    }
                    else if (first == keyword2)
                    {
                        keyword2Count--;
                    }

                    wordsInRange.Dequeue();
                }

                wordsInRange.Enqueue(word);

                if (word == keyword1)
                {
                    keyword1Count++;
                    proximityCount += keyword2Count;
                }
                else if (word == keyword2)
                {
                    keyword2Count++;
                    proximityCount += keyword1Count;
                }

                index++;

                //Console.Write($"{index},  {word},  {count}");
            }

            return proximityCount;
        }

        public static int ProximitySearch(List<string> keywords, int range, string fileName)
        {
            int proximityCount = 0;

            if (keywords.Any())
            {
                var wordsCount = keywords.ToDictionary(word => word, word => 0);
                var index = 0;
                var wordsQueue = new Queue<string>();

                //string minCountKey = keywords[0], maxCountKey = keywords[0];
                //int minCount = int.MaxValue, maxCount = int.MinValue;

                foreach (var word in FileReader.ReadFile(fileName))
                {
                    if(wordsQueue.Count >= range)
                    {
                        // remove first word
                        var wordToRemove = wordsQueue.Dequeue();

                        if(wordsCount.ContainsKey(wordToRemove))
                        {
                            wordsCount[wordToRemove]--;

                            // update minCount and keyword
                            //if(wordsCount[wordToRemove] < minCount)
                            //{
                            //    minCount = wordsCount[wordToRemove];
                            //    minCountKey = wordToRemove;
                            //}
                        }
                    }

                    // add new word
                    wordsQueue.Enqueue(word);

                    if (wordsCount.ContainsKey(word))
                    {
                        wordsCount[word]++;

                        //if (wordsCount[word] > maxCount)
                        //{
                        //    maxCount = wordsCount[word];
                        //    maxCountKey = word;
                        //}

                        proximityCount += GetMinCount(wordsCount, word);
                    }

                    index++;
                }
            }

            return proximityCount;
        }

        private static int GetMinCount(Dictionary<string, int> wordCount, string keyWord)
        {
            int result = 0;

            if(wordCount.Any())
            {
                int minCount = int.MaxValue;
                foreach(var kvp in wordCount)
                {
                    if(kvp.Key != keyWord)
                    {
                        minCount = Math.Min(minCount, kvp.Value);
                    }
                }
                result = minCount;
            }
            return result;
        }

        // Time: O(n), Space: O(n)
        public static int ProximitySearch2(string keyword1, string keyword2, int range, string fileName)
        {
            var count = 0;

            ValidateArguments(keyword1, keyword2, range, fileName);

            var text = File.ReadAllText(fileName);

            var stringSeparators = new string[] { " ", "\r\n" };
            var words = text.Split(stringSeparators, StringSplitOptions.RemoveEmptyEntries);

            var keyword1Count = 0;
            var keyword2Count = 0;


            for (int i = 0; i < words.Length; i++)
            {
                int window = i - range;
                if (window >= 0)
                {
                    if (words[window] == keyword1)
                    {
                        keyword1Count--;
                    }
                    else if (words[window] == keyword2)
                    {
                        keyword2Count--;
                    }
                }

                if (words[i] == keyword1)
                {
                    keyword1Count++;
                    count += keyword2Count;
                }
                else if (words[i] == keyword2)
                {
                    keyword2Count++;
                    count += keyword1Count;
                }
            }

            return count;
        }
        // Time: O(n^2), Space: O(range)
        public static int ProximitySearch3(string keyword1, string keyword2, int range, string fileName)
        {
            ValidateArguments(keyword1, keyword2, range, fileName);

            var count = 0;

            var tuple = CreatePositionsMap(keyword1, keyword2, fileName);

            var l1 = tuple.Item1;
            var l2 = tuple.Item2;

            foreach (var pos1 in l1)
            {
                foreach (var pos2 in l2)
                {
                    var diff = pos2 - pos1;

                    if (Math.Abs(diff) < range)
                        count++;
                    else if (diff >= range)
                        break;
                }
            }

            return count;
        }        

        static Tuple<List<int>, List<int>> CreatePositionsMap(string keyword1, string keyword2, string fileName)
        {
            var text = File.ReadAllText(fileName);
            var stringSeparators = new string[] { " ", "\r\n" };
            var words = text.Split(stringSeparators, StringSplitOptions.RemoveEmptyEntries);

            List<int> l1 = new List<int>();
            List<int> l2 = new List<int>();

            for (int i = 0; i < words.Length; i++)
            {
                if (words[i] == keyword1)
                    l1.Add(i);
                else if (words[i] == keyword2)
                    l2.Add(i);
            }
            return Tuple.Create(l1, l2);
        }

        static void ValidateArguments(string keyword1, string keyword2, int range, string fileName)
        {
            if (string.IsNullOrEmpty(keyword1) || string.IsNullOrEmpty(keyword2))
            {
                Console.WriteLine("Please enter a valid value for keywords.");
                Console.WriteLine("Usage: Proximity Search <keyword1> <keyword2> <range> <input_filename>");
                throw new ArgumentException("Please enter a valid value for keywords.");
            }

            if (range <= 0)
            {
                Console.WriteLine($"Invalud input [{range}] for range. Please enter a positive value for range.");
                Console.WriteLine("Usage: Proximity Search <keyword1> <keyword2> <range> <input_filename>\n\n");
                throw new ArgumentException($"Invalud input [{range}] for range. Please enter a positive value for range.");
            }

            if (!File.Exists(fileName))
            {
                Console.WriteLine($"File [{fileName}] couldn't be found. Please enter file name with correct path.");
                Console.WriteLine("Usage: Proximity Search <keyword1> <keyword2> <range> <input_filename>");
                throw new ArgumentException($"File [{fileName}] couldn't be found. Please enter file name with correct path.");
            }
        }
    }
}
